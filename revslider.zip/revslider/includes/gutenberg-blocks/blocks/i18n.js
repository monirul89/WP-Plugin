wp.i18n.setLocaleData( { '': {} }, 'themepunchblocks' );
