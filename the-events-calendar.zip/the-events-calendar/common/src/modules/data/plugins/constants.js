export const EVENTS_PLUGIN = 'events';
export const EVENTS_PRO_PLUGIN = 'events-pro';
export const TICKETS = 'tickets';
export const TICKETS_PLUS = 'tickets-plus';