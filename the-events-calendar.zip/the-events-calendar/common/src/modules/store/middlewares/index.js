export { default as wpRequest } from './request';
import * as request from './request';
export { request };
