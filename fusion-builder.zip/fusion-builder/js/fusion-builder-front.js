( function( $ ) {

	$( document ).ready( function() {

	} );

} ( jQuery ) );
